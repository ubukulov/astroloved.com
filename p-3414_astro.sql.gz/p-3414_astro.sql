-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:3306
-- Время создания: Май 21 2021 г., 11:01
-- Версия сервера: 10.2.31-MariaDB-cll-lve
-- Версия PHP: 7.3.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `p-3414_astro`
--

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(3, '2014_10_12_000000_create_users_table', 1),
(4, '2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `pg_payment_id` bigint(20) DEFAULT NULL,
  `sum` bigint(20) NOT NULL,
  `tariff` enum('free','week','month','year','consul','course') COLLATE utf8mb4_unicode_ci NOT NULL,
  `pg_salt` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pg_sig` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('processing','paid','canceled') COLLATE utf8mb4_unicode_ci NOT NULL,
  `promocode` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `actived_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `payments`
--

INSERT INTO `payments` (`id`, `user_id`, `pg_payment_id`, `sum`, `tariff`, `pg_salt`, `pg_sig`, `status`, `promocode`, `actived_at`, `created_at`, `updated_at`) VALUES
(3, 39, 197293155, 2440, 'month', 'SJ9nUVKkdrTAdxUM', '7ded1fe6c871735af2dccfbc5db7d6fa', 'paid', NULL, '2020-06-15 07:25:21', '2020-05-15 07:24:51', '2020-05-15 07:25:21'),
(4, 40, 197323167, 2440, 'month', '7R6ApqFIqR2LdiAQ', '327dc53d388c131e38bc125488048a79', 'paid', NULL, '2021-12-31 08:06:06', '2020-05-15 08:03:53', '2020-05-15 08:06:06'),
(8, 39, 209933604, 990, 'week', '9ix8PUMktkmBOs0b', 'c7b5a78fbc9d68fb082bb23d19da111c', 'paid', NULL, '2020-06-07 06:31:57', '2020-05-31 06:31:02', '2020-05-31 06:31:57'),
(9, 39, 209934579, 64960, 'consul', '72tVj6idy9FNu7Rj', 'f552556f29bdf8ccb2f6a74609e48f78', 'paid', NULL, NULL, '2020-05-31 06:32:36', '2020-05-31 06:32:53'),
(10, 39, 209935068, 8220, 'course', 'VntTsEHClijH9G0h', '2af3d69badeacb18c583476b5ea158aa', 'paid', NULL, NULL, '2020-05-31 06:33:19', '2020-05-31 06:33:35'),
(31, 56, 225068728, 2440, 'month', 'hG5ix5kKny1t8FNg', 'c69b19fa8225a9caec11f2b6872a29fb', 'paid', NULL, '2020-07-17 03:01:31', '2020-06-17 02:58:43', '2020-06-17 03:01:31'),
(34, 76, NULL, 0, 'free', NULL, NULL, 'paid', NULL, '2020-08-03 18:00:00', '2020-07-03 18:00:00', '2020-07-03 18:00:00'),
(35, 78, 249561700, 990, 'week', 'rpbuZqJ3dTl8FEzE', 'd884fc15e75a8f6c1a35a39a3ea32971', 'paid', NULL, '2020-07-19 23:43:36', '2020-07-12 23:41:33', '2020-07-12 23:43:36'),
(36, 79, NULL, 0, 'free', NULL, NULL, 'paid', NULL, '2020-08-14 15:39:26', '2020-07-13 15:39:26', '2020-07-13 15:39:26'),
(37, 80, NULL, 0, 'week', NULL, NULL, 'paid', NULL, '2020-07-24 17:20:21', '2020-07-16 17:20:21', '2020-07-16 17:20:21'),
(38, 81, NULL, 2440, 'month', NULL, NULL, 'paid', NULL, '2020-08-24 08:04:29', '2020-07-17 08:04:29', '2020-07-17 08:04:29'),
(45, 85, NULL, 990, 'week', NULL, NULL, 'paid', NULL, '2020-08-22 16:07:10', '2020-08-15 16:07:10', '2020-08-15 16:07:10'),
(46, 49, 287601043, 2440, 'month', 'tXCoq9m5nwZHoj3U', '30703230d1206eff50e9ea57326fde49', 'paid', NULL, '2020-09-17 13:47:53', '2020-08-17 13:35:10', '2020-08-17 13:47:53'),
(47, 99, NULL, 0, 'month', NULL, NULL, 'paid', NULL, '2020-09-21 19:46:04', '2020-08-20 02:14:43', '2020-08-20 02:14:43'),
(48, 84, NULL, 0, 'month', NULL, NULL, 'paid', NULL, '2020-09-21 16:59:46', '2020-08-20 16:59:46', '2020-08-20 16:59:46'),
(49, 104, NULL, 0, 'month', NULL, NULL, 'paid', NULL, '2020-09-21 03:15:26', '2020-08-21 03:15:26', '2020-08-21 03:15:26'),
(50, 54, NULL, 0, 'year', NULL, NULL, 'paid', NULL, '2021-09-11 13:53:34', '2020-09-11 13:53:34', '2020-09-11 13:53:34'),
(51, 44, NULL, 0, 'year', NULL, NULL, 'paid', NULL, '2021-09-11 13:55:01', '2020-09-11 13:55:01', '2020-09-11 13:55:01'),
(52, 106, NULL, 0, 'week', NULL, NULL, 'paid', NULL, '2020-09-29 08:59:55', '2020-09-21 08:59:55', '2020-09-21 08:59:55'),
(53, 87, NULL, 0, 'week', NULL, NULL, 'paid', NULL, '2020-09-29 09:03:15', '2020-09-21 09:03:15', '2020-09-21 09:03:15'),
(54, 108, NULL, 0, 'week', NULL, NULL, 'paid', NULL, '2020-09-29 09:06:05', '2020-09-21 09:06:05', '2020-09-21 09:06:05'),
(55, 109, NULL, 0, 'month', NULL, NULL, 'paid', NULL, '2020-11-05 02:44:22', '2020-10-05 02:44:22', '2020-10-05 02:44:22'),
(56, 110, NULL, 0, 'week', NULL, NULL, 'paid', NULL, '2020-10-19 02:44:56', '2020-10-05 02:44:56', '2020-10-05 02:44:56'),
(57, 111, NULL, 0, 'week', NULL, NULL, 'paid', NULL, '2020-10-20 11:53:37', '2020-10-12 11:53:37', '2020-10-12 11:53:37'),
(58, 112, NULL, 0, 'month', NULL, NULL, 'paid', NULL, '2020-11-13 02:42:26', '2020-10-13 02:42:26', '2020-10-13 02:42:26'),
(59, 114, NULL, 990, 'week', NULL, NULL, 'paid', NULL, '2020-12-18 02:55:46', '2020-12-07 04:37:16', '2020-12-07 04:37:16'),
(60, 40, NULL, 25000, 'consul', NULL, NULL, 'processing', NULL, NULL, '2020-12-07 08:30:26', '2020-12-07 08:30:26');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birth_date` bigint(20) DEFAULT NULL,
  `phone` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmation_token` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `free_count` int(1) NOT NULL DEFAULT 0,
  `round` int(2) NOT NULL DEFAULT 0,
  `isAdmin` int(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `birth_date`, `phone`, `confirmation_token`, `remember_token`, `free_count`, `round`, `isAdmin`, `created_at`, `updated_at`) VALUES
(39, 'Кайрат', 'ubukulov@gmail.com', '2020-04-29 01:30:19', '$2y$10$EkRFi0HKBILOQSaa2dc8YuRrOjjIXHR8wHfv7xu6Brj/a4XC0EBHu', 624672000, '87772504794', NULL, NULL, 3, 0, 1, '2020-04-29 01:28:31', '2020-06-24 16:38:29'),
(40, 'Дмитрий', 'teldim@gmail.com', '2020-04-29 07:25:37', '$2y$10$8u8K74b3zh.xqE8iA3cic./KV3W1B4P3L2oW5XIGFwOoNtvLK3Sca', 97113600, '990674927', NULL, NULL, 3, 18, 0, '2020-04-29 05:45:30', '2021-05-20 23:00:03'),
(41, 'Юлия', 'yuliya@chemodan.kz', '2020-05-02 08:35:50', '$2y$10$PJ.GiSJiqU6uE6I/Co/LteVDQlioP985Bq59kYZnqJMn4kzPuVhEW', 405108000, NULL, NULL, NULL, 3, 0, 0, '2020-05-02 08:34:10', '2020-05-03 18:10:03'),
(42, 'Кайрат', 'mardushev@gmail.com', NULL, '$2y$10$s2GT03dgmRx3D2gzDSjSgedmK9xPCp.GPzohigxAQL/lKDODLIjNW', 0, '87470193748', '5fa2ab4df9ad08eaa1719fc920192093', NULL, 3, 0, 0, '2020-05-24 13:31:09', '2020-06-26 11:16:40'),
(43, 'Диана', 'marchenko.diana@gmail.com', '2020-05-27 09:19:08', '$2y$10$grQt8by4eVWZR0WpH9DsaeRM/qdu/b3flDMwOXaMASSIQd5Avejz6', 0, NULL, NULL, NULL, 3, 0, 0, '2020-05-27 09:18:08', '2020-05-28 18:10:02'),
(44, 'Мирослав', 'telmiroslav@gmail.com', '2020-05-27 09:21:13', '$2y$10$yEyvlwzQId2pbYG76L3zl.xenrqSMuO1awKVmVh5Y.W1idEphi0L.', 0, NULL, NULL, NULL, 3, 14, 0, '2020-05-27 09:20:09', '2021-05-20 23:00:05'),
(45, 'Алефтина', 'alevtina52@me.com', NULL, '$2y$10$dFBEvur9fEIF9sWe5kJYS.A4cMudQEDHpLmaSs.YJR4cmAY1fYdY6', 0, NULL, 'a887317ad20cc98240f53cbc5f932a94', NULL, 1, 0, 0, '2020-05-27 09:53:59', '2020-05-27 09:53:59'),
(46, 'Мирослав', 'mirikilluzionist@gmail.com', '2020-06-01 11:35:37', '$2y$10$MOy/UZqDl.bqH4/ay1Ky1eLbbmuaiPyxn0TC7ebb7kSBhM2gLl9/6', 0, NULL, NULL, NULL, 3, 0, 0, '2020-05-27 09:58:00', '2020-06-02 18:10:02'),
(49, 'Владимир', 'tvvova@mail.ru', '2020-05-27 15:48:07', '$2y$10$upswr6GibavbrO5FkUe.U.yQhnQOo7bT.pb3HcXhTH4h13uPxM4hC', 0, NULL, NULL, NULL, 3, 14, 0, '2020-05-27 15:43:15', '2020-09-16 23:00:03'),
(50, 'Кайрат', 'moikompani@gmail.com', '2020-05-28 10:31:19', '$2y$10$zZNB2aFDASKUPNK0lHJ1Z.YxLMoxFFQytmGOC1OCYIMhhmVh4YNLe', 0, NULL, NULL, NULL, 3, 0, 0, '2020-05-28 10:25:42', '2020-05-29 18:10:02'),
(51, 'Дмитрий', 'dmitry@chemodan.kz', NULL, '$2y$10$z.XD09/zqJ0kymvc2/jiJefmYHZbi7GicQ3.EGyBmZmVupvNHx80W', 0, NULL, 'ea838f7700d770c6c3528e17189bd44a', NULL, 1, 0, 0, '2020-06-03 00:49:35', '2020-06-03 00:49:35'),
(52, 'Юля', 'yuliya@chemidan.kz', NULL, '$2y$10$eeli.7kHTFyq3lpxk6X0fuEgX/Pp1mTPryb1LaJMJv5t7hPONKgXq', 0, NULL, 'b019faeb7cf2b9a930d6aee321a6f3a7', NULL, 1, 0, 0, '2020-06-03 04:50:57', '2020-06-03 04:50:57'),
(53, 'Евгений', 'tevgen78@icloud.com', '2020-06-08 13:33:22', '$2y$10$kM/smi6Lf90/AsbU5yzIB.j6uXepMAXmmaVvemws4YmJPCZ2dCUIO', 0, NULL, NULL, NULL, 3, 0, 0, '2020-06-08 13:30:43', '2020-06-09 18:10:02'),
(54, 'Юлия', 'telyul@gmail.com', '2020-06-09 03:15:57', '$2y$10$dhRSyLbXNfNP1..Gh3R0/ularw6ocbzFZ/6NtvKTNtB3uN6mPHO.6', 405108000, '87019254925', NULL, NULL, 3, 14, 0, '2020-06-08 16:48:14', '2021-05-20 23:00:04'),
(56, 'Жанна', 'zheanna.21.07.a@gmail.com', '2020-06-13 11:34:24', '$2y$10$nq4OHocxCkSw7v3T0O24Xe0.srxNwMMNMrpwLxQcvXJhtijssDf72', 0, NULL, NULL, NULL, 3, 17, 0, '2020-06-13 11:33:58', '2020-07-16 18:05:17'),
(57, 'Ульяна', 'leonovauliana194@yahoo.com', NULL, '$2y$10$.jU3MY3OYBnWws5Zv.U2meyNEOt7Y8lR0dmVgQobOBQPv3hVVbYFu', 0, NULL, '4f76b2095680e4e3fc9a0865c224df81', NULL, 1, 0, 0, '2020-06-13 14:11:18', '2020-06-13 14:11:18'),
(58, 'Ульяна', 'leonovauliana194@gmail.com', NULL, '$2y$10$n9thf/IUYWh173j5AC44xegpADWJJWOWCTlAu/m0J1Kq4oKNd2Ohy', 0, NULL, '290e74e8b25d0f1160803cc326440168', NULL, 1, 0, 0, '2020-06-13 14:11:31', '2020-06-13 14:11:31'),
(59, 'Владимир', 'vovan.muratov@mail.ru', '2020-06-14 07:50:53', '$2y$10$9ajeVFGHi3YV904yIwH8UOUijxcCJbpHTERcEVZuC10Cu14/.jsT2', 0, NULL, NULL, NULL, 3, 0, 0, '2020-06-14 07:50:11', '2020-06-15 18:10:02'),
(60, 'Соня', 'lopsonka13@gmail.com', NULL, '$2y$10$ifFSF3EOFEw1doA4e//Js.SXTXz9bsINcCu1/tHH/kDiTIP9bO6y6', 0, NULL, '84b7e5b0bb4fbd3d707ffb3ea17a14b6', NULL, 1, 0, 0, '2020-06-14 14:10:29', '2020-06-14 14:10:29'),
(61, 'Елена', 'zhurlena81@gmail.com', NULL, '$2y$10$zZokNUNF7m99zTZNt9jyMO2Cj4CEr4UjFO1jPMXabPwNmj3/O4pKi', 0, NULL, '8b42b4e9e9e04851a5320146cf70c0b9', NULL, 1, 0, 0, '2020-06-14 18:12:02', '2020-06-14 18:12:02'),
(62, 'Валерия', 'valeriia308@gmail.com', '2020-06-15 00:16:26', '$2y$10$V//wKo47G46/6NC8l56n7OXkDUBmGyXNfWTvrLQgxqiWkxagl1mSa', 0, NULL, NULL, NULL, 3, 0, 0, '2020-06-15 00:15:58', '2020-06-16 18:10:02'),
(63, 'Елена', 'guryanovaen1972@gmail.ru', NULL, '$2y$10$lbm4QyZrQueBbQQKm6a3.OVbueM0Ht8NApoYBeCC4ZQYHcJqLy2E.', 0, NULL, '6c44989a0b891c536a1d6ad715410427', NULL, 1, 0, 0, '2020-06-15 05:45:09', '2020-06-15 05:45:09'),
(64, 'Дина', 'dina.mutalipova@gmail.com', '2020-06-15 07:13:57', '$2y$10$yvidN7Jq5bztAoKYUrfR4O0oRe1xysb/LugUTQlpdYXsFVCc24mEW', 0, NULL, NULL, NULL, 3, 0, 0, '2020-06-15 06:45:10', '2020-06-16 18:10:03'),
(65, 'Ксения', 'kseniys1986@list.ru', NULL, '$2y$10$SjIrdEnApauyiBMl8wzBp.ZQDr1dcL7lo4kHN4TOkSNyXLpwpn.0K', 0, NULL, 'fa18124a4da4be760a5092b01fbefecd', NULL, 1, 0, 0, '2020-06-15 10:38:31', '2020-06-15 10:38:31'),
(67, 'Татьяна', 'tako074@mail.ru', '2020-06-17 04:50:18', '$2y$10$a31tTGUujV262UWHYX7X5eP5RP1ljKel4wSEtUR/lYmDN.PtI9UtO', 0, NULL, NULL, NULL, 3, 0, 0, '2020-06-17 04:22:11', '2020-06-18 18:10:02'),
(68, 'Светлана', 'svetlana.m.yakovleva@gmail.com', NULL, '$2y$10$QuAjXh4wJHTilFNyz0SnnuJazysiIGxulNPMjhJ..PEgzqp1QzUPW', 0, NULL, 'a8955e680f1b06f654467b1d39cb9c56', NULL, 1, 0, 0, '2020-06-19 14:10:24', '2020-06-19 14:10:24'),
(69, 'Айгерим', 'aigerimalpeisova@gmail.com', NULL, '$2y$10$M5Lwgl6KhGEC6TSZ.MqB/OOI91uuOZM58mIeFMiYJaN3rUYbw9fEG', 0, NULL, '4753a8243a8972a3e635b47d2f68b2e0', NULL, 1, 0, 0, '2020-06-19 14:45:36', '2020-06-19 14:45:36'),
(70, 'РА', '21092503@ukr.net', NULL, '$2y$10$xp8FIB4V.pYujDRbd7mNgu2U129rvUewFULIbLN//16ebNhOdXwhe', 0, NULL, '6dbdf422a7d0470fbe9e4aa3dcf3bd66', NULL, 1, 0, 0, '2020-06-22 09:21:05', '2020-06-22 09:21:05'),
(72, 'Ирина', '177irina@mail.ru', NULL, '$2y$10$mF8G4DvwbQcuyjbmvj/px.1CnYxEUQqM0BIEUnmfDqccF1UXcaAoa', 0, '+79251529285', '99fefb99fe03347766fa73112cfd66ac', NULL, 1, 0, 0, '2020-07-01 13:06:56', '2020-07-01 13:10:52'),
(74, 'Кайрат', 'kairat_ubukulov@mail.ru', '2020-07-02 14:43:37', '$2y$10$g7IyZ/c/xr6.n0loebjFOO0ZBP65QClUR1mxWmaXvGNE7i1Cy3tDm', 0, NULL, NULL, NULL, 3, 3, 0, '2020-07-02 14:43:22', '2020-07-03 18:10:02'),
(76, 'Данара', 'danara.talisman@gmail.com', NULL, '123456', 741891600, NULL, 'abd9aa4998941ce95a70aeac2721b1ce', NULL, 3, 15, 0, '2020-07-04 04:18:47', '2020-08-02 23:00:02'),
(77, 'Мирослав', 'telmirosla@gmail.com', NULL, '$2y$10$qFLmftucMfWVY.a/qvEqKubHhG5TM7IFkEyWdE2GJCow.fp.obuFK', 0, NULL, '5a333f0696a3093189a25e5dd5f73b2d', NULL, 1, 0, 0, '2020-07-08 10:01:47', '2020-07-08 10:01:47'),
(78, 'Мира', 'mirusya_85@mail.ru', '2020-07-12 23:41:01', '$2y$10$2dcyhyZRsBCCEmkafinDZeaaZjUPIuZDcIQcaAdB77F9C1GEvZKzm', 0, NULL, NULL, NULL, 3, 11, 0, '2020-07-12 23:40:27', '2020-07-19 18:05:04'),
(79, 'Лена', 'Tatosik_05@mail.ru', NULL, '$2y$10$qFLmftucMfWVY.a/qvEqKubHhG5TM7IFkEyWdE2GJCow.fp.obuFK', NULL, NULL, NULL, NULL, 3, 14, 0, '2020-07-13 15:30:46', '2020-08-13 23:00:05'),
(80, 'Леся', 'LesyaKos@inbox.ru', NULL, '$2y$10$qFLmftucMfWVY.a/qvEqKubHhG5TM7IFkEyWdE2GJCow.fp.obuFK', NULL, NULL, NULL, NULL, 3, 8, 0, '2020-07-16 17:19:12', '2020-07-23 23:00:06'),
(81, 'Татьяна', 'ktvuhka@gmail.com', NULL, '123456', NULL, NULL, NULL, NULL, 3, 4, 0, '2020-07-17 08:00:32', '2020-08-23 23:00:04'),
(82, 'Азамат', 'azamat_aleuhanov@mail.ru', '2020-07-25 17:39:51', '$2y$10$fkIB4m1rtV2PIyIW/h74GeJ4Ks1wdjYOJfY3oOBpt5D6j7tGLZsF2', 0, NULL, NULL, NULL, 3, 3, 0, '2020-07-25 17:38:51', '2020-07-26 23:05:01'),
(83, 'Азамат', 'azamover@mail.ru', '2020-07-27 09:45:46', '$2y$10$r4uq0QgBsjZa8weCEbuJxe8kTYDitdkv0TjWhGuXkvlX48KWiIJdG', 0, NULL, NULL, NULL, 3, 3, 0, '2020-07-27 09:45:14', '2020-07-28 23:05:02'),
(84, 'Елена', 'Elena.sochneva.79@mail.ru', '2020-08-07 08:28:17', '$2y$10$M56G3LTZa3NBhPYWhy86neBPiOiYJkfXeuySh3Gx3q80FeP8lwVwi', 0, NULL, NULL, NULL, 3, 17, 0, '2020-08-07 07:06:26', '2020-09-20 23:00:09'),
(85, 'Алия', 'aliyatg@mail.ru', '2020-08-15 16:06:02', '123456', NULL, NULL, NULL, NULL, 3, 7, 0, '2020-08-15 16:06:02', '2020-08-21 23:00:05'),
(86, 'AlTel', '7558925@mail.ru', '2020-08-17 02:09:25', '$2y$10$MT.vU9tr4BrVdG5q6wD6IuJL82K5J6sXpquv0/1iLgYMre.ve3Tw.', 0, NULL, NULL, NULL, 3, 3, 0, '2020-08-17 02:08:59', '2020-08-18 23:05:01'),
(87, 'Ирина', 'irina_aia78@mail.ru', '2020-08-17 02:25:38', '$2y$10$phYpEjdZJSr3WuVYi9wH3eSSieQK6ESWub9FmE63FojoSQYWtslsq', 254880000, NULL, NULL, NULL, 3, 12, 0, '2020-08-17 02:25:19', '2020-09-28 23:01:37'),
(88, 'Malika', 'ye.malika@gmail.com', '2020-08-17 03:55:25', '$2y$10$pt6MNs9pOKmgWWdlchWiveUJeL4wfkro4rQgb0B2rHoMKlB92YPda', 0, NULL, NULL, NULL, 3, 3, 0, '2020-08-17 03:55:03', '2020-08-18 23:05:03'),
(89, 'Аяжан', 'aya_0024@mail.ru', '2020-08-17 05:35:08', '$2y$10$0lckDDWgAoZvKgGCJ.m.PeL2P2c1qfOqm32g21II1fBL9Ls/h7zeC', 0, NULL, NULL, NULL, 3, 3, 0, '2020-08-17 05:15:54', '2020-08-18 23:05:03'),
(90, 'Жадыра', 'zhaditian@gmail.com', NULL, '$2y$10$ZAACMBzPEbFzaAfy/aihW.klYGpfY9ZcX10jRADCD.3jyJvz1n83y', 0, NULL, 'a06d857ea4fb4ae38dd560b4c21718b3', NULL, 1, 0, 0, '2020-08-17 06:44:22', '2020-08-17 06:44:22'),
(91, 'Светлана', 'ms.lady.ubarova@mail.ri', NULL, '$2y$10$HR4W/iMxvVAQR9GEnCh9PON7BiIBMSv.YTf4GSEcpYOXh3sLhCphO', 0, NULL, '24f67b2efb04e9ab149f7a1a0f662b43', NULL, 1, 0, 0, '2020-08-17 07:07:02', '2020-08-17 07:07:02'),
(92, 'Назыма', 'nazyma92@gmail.com', '2020-08-17 08:01:48', '$2y$10$XUmON4x688GmudvQR8bZf.I.xNc49aoqImXwWMYlnSQl2VEePbLja', 0, NULL, NULL, NULL, 3, 3, 0, '2020-08-17 08:00:20', '2020-08-18 23:05:04'),
(93, 'Альбина', 'albina_1906@mail.ru', '2020-08-17 17:12:16', '$2y$10$sZgfVm8.U5ZeMKyqd3riDepLHeRJL/5ORxHEU09SGUazkoLc73Nye', 0, NULL, NULL, NULL, 3, 3, 0, '2020-08-17 17:10:45', '2020-08-18 23:05:05'),
(94, 'Валентина', 'kmsvalentina@gmail.com', '2020-08-18 03:49:28', '$2y$10$EwjXFr/Mo9.WLQziSZ0h5ea/SMCgkVFqRyk9Gy.OSM8kxhzUDyogC', 0, NULL, NULL, NULL, 3, 3, 0, '2020-08-18 03:47:14', '2020-08-19 23:05:02'),
(95, 'Юлия', 'yulia.serenko@gmail.com', NULL, '$2y$10$.YU2W5tk6SzzixPcxrGihe9izlVJrPS7Z1eKqQtOWmOJC/syyVvx6', 0, NULL, 'b5509e81313eaf61171a73726618ee2f', NULL, 1, 0, 0, '2020-08-18 06:59:35', '2020-08-18 06:59:35'),
(96, 'Ardak', 'ardakabdizh@gmail.com', '2020-08-18 12:58:31', '$2y$10$QzLIewQZHVexb122NO63t.EvxEgl6kytWwdTsBE2QTG125Wvs.Ph2', 0, NULL, NULL, NULL, 3, 3, 0, '2020-08-18 12:57:55', '2020-08-19 23:05:02'),
(97, 'Мадина', 'marti_2890@mail.ru', NULL, '$2y$10$YpKmonArBj.fvaryu2HUY.Fy0wBS/C10la.tR1sHZ0S9AOv2ipjFu', 0, NULL, '4e944a1559e4d6978e67dbf20947b55f', NULL, 1, 0, 0, '2020-08-18 14:20:16', '2020-08-18 14:20:16'),
(98, 'Айым', 'aiym5432@gmail.com', '2020-08-19 08:09:02', '$2y$10$j2FKki7FW3RTfLoRmnwcwOlk77OdoDJzTJXdxodsRszqp24Pcmn2y', 0, NULL, NULL, NULL, 3, 3, 0, '2020-08-19 08:08:36', '2020-08-20 23:05:02'),
(99, 'Джамила', 'jamika_@mail.ru', '2020-08-20 02:17:12', '$2y$10$5km7Fi9230e53Na5B1OBluvjNeTISR0nluOH4vCuPjn7ht4MsEGcy', 0, NULL, NULL, NULL, 3, 16, 0, '2020-08-20 02:10:27', '2020-09-20 23:00:06'),
(100, 'Dzhamila', 'dzhamantonik@gmail.com', '2020-08-21 21:40:53', '$2y$10$OUYTONq2EB3lGtW/xkBF2OdC6kEquChiXnPdNeumQlxHFsISqtfLC', 0, NULL, NULL, NULL, 3, 3, 0, '2020-08-20 02:16:15', '2020-08-22 23:05:02'),
(101, 'Светлана', 'ms.lady.uvarovs@mail.ru', NULL, '$2y$10$w//G5hhHDgFg7csjZEBj6uCeBRp0n1yM.GDvOZvTiI/yAaCfjZVhy', 0, NULL, 'fbf6bf0d09c3f776a015cd914a12573b', NULL, 1, 0, 0, '2020-08-20 14:30:39', '2020-08-20 14:30:39'),
(102, 'Светлана', 'ms.lady.uvarova@mail.ru', '2020-08-20 14:32:27', '$2y$10$wgdHIVuIG4qH5VmVQI3XCuW3PhWQR6I73BjXpmNlJPOd7xZ9iM45G', 0, NULL, NULL, NULL, 3, 3, 0, '2020-08-20 14:31:15', '2020-08-21 23:05:03'),
(104, 'Юлия', 'sladkaia1994@mail.ru', '2020-08-21 03:14:31', '123456', 0, NULL, NULL, NULL, 3, 15, 0, '2020-08-21 03:14:31', '2020-09-20 23:00:11'),
(105, 'Олеся', 'selyukova.olesya@mail.ru', '2020-08-26 06:53:38', '$2y$10$zqL.VE.8qCcyXqrdvwa3NOrD8vLKCqKsm/1pdspVV8yg4xoQok.b.', 0, NULL, NULL, NULL, 3, 3, 0, '2020-08-26 06:50:44', '2020-08-27 23:05:01'),
(106, 'Анна', 'anna@avtrade.kz', NULL, '123456', 524448000, NULL, NULL, NULL, 3, 9, 0, '2020-09-21 08:55:21', '2020-09-28 23:01:37'),
(108, 'Татьяна', 'tataovhcinnikova@mail.ru', NULL, '123456', -147571200, NULL, NULL, NULL, 3, 9, 0, '2020-09-21 09:03:52', '2020-09-28 23:01:41'),
(109, 'Ольга', 'o.gridchina@mail.ru', '2020-10-05 02:40:44', '123456', 239738400, NULL, NULL, NULL, 3, 13, 0, '2020-10-05 02:40:44', '2020-11-04 23:00:05'),
(110, 'Марина', 'MRNmoiseeva@gmail.com', '2020-10-05 02:42:18', '123456', 417204000, NULL, NULL, NULL, 3, 15, 0, '2020-10-05 02:42:18', '2020-10-18 23:00:06'),
(111, 'Светлана', 'tsvetkova.s@mail.ru', '2020-10-12 11:51:28', '123456', 30823200, NULL, NULL, NULL, 3, 8, 0, '2020-10-12 11:51:28', '2020-10-19 23:00:06'),
(112, 'Вероника', 'ustaviskay@mail.ru', '2020-10-13 02:41:23', '123456', 890848800, NULL, NULL, NULL, 3, 14, 0, '2020-10-13 02:41:23', '2020-11-12 23:00:05'),
(113, 'Кристина', 'kristina.p89@mail.ru', '2020-10-14 10:23:08', '$2y$10$X68mGiS9zIqHWvZbOOw8nu7G93/cNsEc0zq93vT.1UG0.K9f3Ev6S', 0, NULL, NULL, NULL, 3, 3, 0, '2020-10-14 10:22:51', '2020-10-15 23:05:02'),
(114, 'Ольга', 'ms.moseevskayastruk@mail.ru', NULL, '$2y$10$RN/K4qShkY0xreHNRfXxSe/PDylipCD1NRELYKysDJFu78d1i9Bn6', 0, NULL, '0573b4fa93e028116cdfb4bce97ba2d0', NULL, 3, 8, 0, '2020-12-07 04:16:16', '2020-12-17 23:00:04');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Индексы таблицы `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payments_user_id_foreign` (`user_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
